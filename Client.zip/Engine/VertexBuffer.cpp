#include "pch.h"
#include "VertexBuffer.h"

VertexBuffer::VertexBuffer()
{

}

VertexBuffer::~VertexBuffer()
{

}
