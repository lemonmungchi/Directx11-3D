#pragma once

class Utils
{
public:
	static bool StartsWith(string str, string comp);
	static bool StartsWith(wstring str, wstring comp);

	static wstring ToWString(string value);
	static string ToString(wstring value);
};

